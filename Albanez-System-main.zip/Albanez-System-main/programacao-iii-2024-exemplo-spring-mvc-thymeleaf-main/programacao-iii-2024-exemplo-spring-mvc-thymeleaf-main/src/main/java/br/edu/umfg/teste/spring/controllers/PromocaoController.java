package br.edu.umfg.teste.spring.controllers;

import br.edu.umfg.teste.spring.entities.Promocao;
import br.edu.umfg.teste.spring.entities.PromocaoProduto;
import br.edu.umfg.teste.spring.entities.Produto;
import br.edu.umfg.teste.spring.repositories.PromocaoRepository;
import br.edu.umfg.teste.spring.repositories.ProdutoRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Controller
public class PromocaoController {

    @Autowired
    private PromocaoRepository promocaoRepository;

    @Autowired
    private ProdutoRepository produtoRepository;

    // 🟰 GET - Página de cadastro da promoção
    @GetMapping("/cadastroPromocao")
    public String exibirFormularioCadastro(Model model) {
        model.addAttribute("promocao", new Promocao());
        model.addAttribute("produtos", produtoRepository.findAll());
        return "cadastroPromocao";
    }

    // 🟰 POST - Salvar nova promoção
    @PostMapping("/promocao/salvar")
    @Transactional
    public String salvarPromocao(
            @ModelAttribute Promocao promocao,
            @RequestParam List<Long> produtoIds,
            @RequestParam List<BigDecimal> valoresDesconto
    ) {
        List<PromocaoProduto> produtosPromocao = new ArrayList<>();

        for (int i = 0; i < produtoIds.size(); i++) {
            Long produtoId = produtoIds.get(i);
            BigDecimal valorDesconto = valoresDesconto.get(i);

            Produto produto = produtoRepository.findById(produtoId)
                    .orElseThrow(() -> new RuntimeException("Produto não encontrado: " + produtoId));

            BigDecimal precoOriginal = BigDecimal.valueOf(produto.getPrecoVenda());
            BigDecimal precoPromocional = precoOriginal.subtract(valorDesconto);

            // Cria relação PromocaoProduto
            PromocaoProduto promocaoProduto = new PromocaoProduto();
            promocaoProduto.setProduto(produto);
            promocaoProduto.setPrecoOriginal(precoOriginal);
            promocaoProduto.setPrecoPromocional(precoPromocional);

            produtosPromocao.add(promocaoProduto);

            // Atualiza o preço do produto
            produto.setPrecoVenda(precoPromocional.doubleValue());
            produtoRepository.save(produto);
        }

        promocao.setProdutos(produtosPromocao);
        promocao.setStatus(Promocao.StatusPromocao.ATIVO);
        promocao.setDataInicio(LocalDateTime.now());
        promocaoRepository.save(promocao);

        return "redirect:/listaPromocao";
    }

    // 🟰 GET - Lista de promoções
    @GetMapping("/listaPromocao")
    public String listarPromocoes(Model model) {
        List<Promocao> promocoes = promocaoRepository.findAll();

        for (Promocao promocao : promocoes) {
            if (promocao.getStatus() == Promocao.StatusPromocao.ATIVO
                    && promocao.getDataFim().isBefore(LocalDateTime.now())) {
                encerrarPromocao(promocao);
            }
        }

        model.addAttribute("promocoes", promocaoRepository.findAll());
        return "listaPromocao";
    }

    // 🟰 GET - Detalhes de uma promoção
    @GetMapping("/promocao/{id}")
    public String detalhesPromocao(@PathVariable Long id, Model model) {
        Promocao promocao = promocaoRepository.findByid(id);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        String dataInicioFormatada = promocao.getDataInicio().format(formatter);
        String dataFimFormatada = promocao.getDataFim().format(formatter);

        model.addAttribute("promocao", promocao);
        model.addAttribute("dataInicioFormatada", dataInicioFormatada);
        model.addAttribute("dataFimFormatada", dataFimFormatada);

        return "detalhesPromocao";
    }

    // 🟰 GET - Editar promoção
    @GetMapping("/promocao/editar/{id}")
    public String editarPromocao(@PathVariable Long id, Model model) {
        Promocao promocao = promocaoRepository.findByid(id);
        model.addAttribute("promocao", promocao);
        model.addAttribute("produtos", produtoRepository.findAll());
        return "editarPromocao";
    }

    // 🟰 POST - Atualizar promoção editada
    @PostMapping("/promocao/atualizar/{id}")
    @Transactional
    public String atualizarPromocao(
            @PathVariable Long id,
            @ModelAttribute Promocao promocaoAtualizada,
            @RequestParam List<Long> produtoIds,
            @RequestParam List<BigDecimal> valoresDesconto
    ) {
        Promocao promocao = promocaoRepository.findByid(id);

        // Primeiro: restaurar preços dos produtos antigos
        for (PromocaoProduto promocaoProduto : promocao.getProdutos()) {
            Produto produto = promocaoProduto.getProduto();
            if (produto != null) {
                produto.setPrecoVenda(promocaoProduto.getPrecoOriginal().doubleValue());
                produtoRepository.save(produto);
            }
        }

        // Depois: limpar produtos antigos
        promocao.getProdutos().clear();

        // Agora: adicionar os novos produtos
        List<PromocaoProduto> novosProdutosPromocao = new ArrayList<>();
        for (int i = 0; i < produtoIds.size(); i++) {
            Long produtoId = produtoIds.get(i);
            BigDecimal valorDesconto = valoresDesconto.get(i);

            Produto produto = produtoRepository.findById(produtoId)
                    .orElseThrow(() -> new RuntimeException("Produto não encontrado: " + produtoId));

            BigDecimal precoOriginal = BigDecimal.valueOf(produto.getPrecoVenda());
            BigDecimal precoPromocional = precoOriginal.subtract(valorDesconto);

            PromocaoProduto novoPromocaoProduto = new PromocaoProduto();
            novoPromocaoProduto.setProduto(produto);
            novoPromocaoProduto.setPrecoOriginal(precoOriginal);
            novoPromocaoProduto.setPrecoPromocional(precoPromocional);

            novosProdutosPromocao.add(novoPromocaoProduto);

            produto.setPrecoVenda(precoPromocional.doubleValue());
            produtoRepository.save(produto);
        }

        promocao.setProdutos(novosProdutosPromocao);
        promocao.setNome(promocaoAtualizada.getNome());
        promocao.setDataFim(promocaoAtualizada.getDataFim());

        promocaoRepository.save(promocao);

        return "redirect:/listaPromocao";
    }

    // 🟰 POST - Encerrar promoção manualmente
    @PostMapping("/promocao/encerrar/{id}")
    public String encerrarPromocaoManual(@PathVariable Long id) {
        Promocao promocao = promocaoRepository.findByid(id);
        encerrarPromocao(promocao);
        return "redirect:/listaPromocao";
    }

    // 🔵 Função privada para encerrar promoções
    @Transactional
    private void encerrarPromocao(Promocao promocao) {
        for (PromocaoProduto promocaoProduto : promocao.getProdutos()) {
            Produto produto = promocaoProduto.getProduto();
            if (produto != null) {
                produto.setPrecoVenda(promocaoProduto.getPrecoOriginal().doubleValue());
                produtoRepository.save(produto);
            }
        }
        promocao.setStatus(Promocao.StatusPromocao.ENCERRADO);
        promocao.setDataFim(LocalDateTime.now());
        promocaoRepository.save(promocao);
    }
}
